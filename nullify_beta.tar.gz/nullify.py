#!/usr/bin/env python3
# coding=utf-8

###########################################################################################################################################################
###########################################################################################################################################################
# This tool provides the functionality to invoke a nulling process of a selected (external) hard drive. Afterwards,
# a check will be done to determine whether the nulling process has been successful. Finally, a report (html
# and pdf) is created, which can optionally be printed.
###########################################################################################################################################################
# The tool consists of three files: nullify.py, __checking.py and __report.py
###########################################################################################################################################################
# To use the tool, the following dependencies are necessary:
# 	lsblk, dd, hdparm, lp, cupds, pdfkit
#	cups: 
#	pdfkit:
#		sudo apt-get install python-pip
#		sudo pip install pdfkit
# 		sudo apt-get install wkhtmltopdf
###########################################################################################################################################################
###########################################################################################################################################################

"""
This Python script offers the ability to erase hard drives forensically sound.
After the nulling process, the hard drive will be checked to ensure that the
process ended successfully. Finally, a report (HTML as well as PDF) will be
created, which can optionally be printed.
"""

__version__ = '"1.0"'
__date__ = '"July 2016"'


import time
from time import localtime
import subprocess
from subprocess import Popen, PIPE
import signal
import sys
from sys import stdout
import os
import distutils.spawn
import re
import math

# import __report
# import __checking

modules = []

###########################################################################################################################################################
###########################################################################################################################################################
# this function is the main function of the tool
# it will guide the user through choosing a drive, nulling, checking, and reporting


def main():
	precourse()
	dependency_check()

	print('\033[1m\033[37m###############################################################################')
	print()

	while True:
		# accept only characters (upper/lower)
		name = input('\033[0mUser: \033[1m\033[37m')
		if not name or not re.match("^[a-zA-Z]*$", name) or name.isspace():
			print('\033[91mInvalid input! Please try again.')
			print()
		else:
			break
			

	while True:
		# accept only characters (upper/lower) and digits
		dtID = input('\033[0mCase number: \033[1m\033[37m')
		if not dtID or not re.match("^[a-zA-Z0-9]*$", dtID) or dtID.isspace():
			print('\033[91mInvalid input! Please try again.')
			print()
		else:
			break
	print()
	print('\033[1m\033[37m###############################################################################')

	# blocksOkay = False
	while(True):
		print()
		print('\033[0mConnect the hard drive now (again) and confirm with <ENTER>. ' \
			+ '(the program will\nwait an additional 3 seconds to ensure the device is ready)\n')

		input('Waiting for user input... ')
		for i in range(1,4):
			print('\033[1m\033[37m' + str(i) + '\033[0m')
			time.sleep(1)

		diskToNull, attributes, index = chooseDisk()

		print('\033[1m\033[37m###############################################################################\033[0m')
		print()

		# blocks = __checking.getDeviceSize('/dev/' + attributes[0][index]) / 512
		blocks = modules[1].getDeviceSize('/dev/' + attributes[0][index])
		try:
			blocks = int(blocks) / 512
			break
		except ValueError as ex:
			print("\033[91mError: The size of the hard drive could not be determined.\033[0m")
			blocks = 0
			print()
			print("Program will terminate now, as it can not perform properly.")

	thousand = blocks / 1000
	half = blocks / 2
	numOfBlocksToBeChecked = 3 * thousand
	whichCheck = modules[1].chooseCheckType(blocks, thousand, half, numOfBlocksToBeChecked)	

	restart = 1 # default is to terminate the program
	while True:
		print('\033[1m\033[37m###############################################################################')
		print()
		confirm(attributes, index, whichCheck)
		duration = nulling(diskToNull, attributes, index, blocks)
		print('\033[1m\033[37m###############################################################################')
		print()
		# restart = __checking.checkType('/dev/' + attributes[0][index], blocks, checkNow, thousand, half, numOfBlocksToBeChecked)
		restart = modules[1].checkRoutine('/dev/' + attributes[0][index], blocks, whichCheck, thousand, half, numOfBlocksToBeChecked)
		if restart == 0:
			print('/dev/\033[1m\033[37m' + attributes[0][index] + ' \033[0;32mhas been successfully nulled and checked.\033[0m')
		elif restart == 'skipped':
			print('/dev/\033[1m\033[37m' + attributes[0][index] + ' \033[0;32mhas been successfully nulled \033[91mBUT NOT CHECKED!\033[0m')
		elif restart == 1:
			sys.exit('Program will terminate now.\033[0m')
		elif restart == 2:
			continue

		# reportFile = __report.createReport(name, dtID, duration, attributes, index, restart)
		reportFile = modules[0].createReport(name, dtID, duration, attributes, index, restart)
		# reportFile = "empty.pdf"
		print()
		printReport = input("Do you want to print the report now? (y/n) ")
		if printReport == "y":
			os.system("lp " + reportFile)
		else:
			print()
			print('You can find the report in ' + os.getcwd() + '/' + reportFile)
		print()
		print('Program will terminate now.\033[0m')
		sys.exit()

		# elif restart == 'skipped':
		# 	print('/dev/\033[1m\033[37m' + attributes[0][index] + ' \033[0;32mhas been successfully nulled \033[91mBUT NOT CHECKED!\033[0m')
		# 	# reportFile = __report.createReport(name, dtID, duration, attributes, index, restart)
		# 	reportFile = modules[0].createReport(name, dtID, duration, attributes, index, restart)
		# 	printReport = raw_input("Do you want to print the report now? (y/n) ")
		# 	if printReport == "y":
		# 		os.system("lp " + reportFile)
		# 	print('Program will terminate now.\033[0m')
		# 	sys.exit()

		# elif restart == '1':
		# 	print('Program will terminate now.\033[0m')
		# 	sys.exit()

###########################################################################################################################################################
# this function provides the user the ability to choose a disk that will be nullified
# and returns the chosen disk

def chooseDisk():
	print()
	print('The following hard drives are available for erasing. Note that /dev/sda is\nbeing omitted due to safety reasons!')
	print()

	attributes = False
	while attributes == False:
		attributes = listDevices()
	print()

	while True:
		diskToNull = input('Choose a hard drive by entering the device name (sdb, sdc, ...): \033[1m\033[37m')
		if diskToNull not in attributes[0]:
			print('\033[91mNot found...\033[0m')
			print('Please choose again.')
		else:
			index = attributes[0].index(diskToNull)
			break
		print()
	print()

	return diskToNull, attributes, index

###########################################################################################################################################################
# this function will list all available devices using 'hdparm -I <device>' and adds
# the attributes 'logical name', 'model', 'serial' and 'size to  seperate lists,
# and returns a list called 'attributes' containing the previously mentioned lists

def listDevices():
	logicalNameshdparm = []
	modelshdparm = []
	serialshdparm = []
	sizes1024hdparm = []
	sizes1000hdparm = []

	reg = re.compile("sd+[b-z]")

	# ps = subprocess.Popen(['lsblk', '-no', 'name'], stdout=subprocess.PIPE)
	ps = subprocess.getoutput('lsblk -no name')
	# for line in ps.stdout:
	for line in ps.split('\n'):
	# check for logical name: e.g., /dev/sdb or /dev/sdc
	# omit sda out of safety reasons
	# if re.match("sd+[b-z]", str(line)):
	# if reg.match(str(line)):
		if reg.match(line):
			print("\tName: \033[1m\033[37m/dev/", end='')
			# add new array entry and initialize with error value to ensure that for every device an entry exists
			# if for some reason for some devices, e.g., the size can not be determined, this will be displayed
			logicalNameshdparm.append("could not determine logical name")
			modelshdparm.append("could not determine model")
			serialshdparm.append("could not determine serial")
			sizes1024hdparm.append("could not determine size")
			sizes1000hdparm.append("could not determine size")
			# suppress space between two print statements
			sys.stdout.softspace = 0
			# print sdb, sdc etc. in bold white
			print(line + '\033[0m'),
			logicalNameshdparm[len(logicalNameshdparm) - 1] = line.rstrip()
			# ps2 = subprocess.Popen(['hdparm', '-I', '/dev/' + line[:3]], stdout=subprocess.PIPE)
			# print(line[:3])
			hdparm = 'hdparm -I /dev/' + str(line[:3])
			# print(hdparm)
			try:
				ps2 = subprocess.getoutput(hdparm)
				# for line2 in ps2.stdout:
				for line2 in ps2.split('\n'):
					if "Model Number:" in line2:
						print(line2[:-1])
						modelshdparm[len(modelshdparm) - 1] = line2[21:].rstrip()
						continue
					elif "Serial Number" in line2:
						print(line2[:-1])
						serialshdparm[len(serialshdparm) - 1] = line2[21:].rstrip()
						continue
					elif "device size with M" in line2:
						print(line2[:-1])
						if "device size with M = 1024" in line2:
							sizes1024hdparm[len(sizes1024hdparm) - 1] = line2[38:].rstrip()
							continue
						else:
							sizes1000hdparm[len(sizes1000hdparm) - 1] = line2[38:].rstrip()
				print()
				attributes = []
				attributes.append(logicalNameshdparm)
				attributes.append(modelshdparm)
				attributes.append(serialshdparm)
				attributes.append(sizes1024hdparm)
				attributes.append(sizes1000hdparm)
				return attributes
			except UnicodeDecodeError as ude:
				print()
				print('Error querying hdparm.')
				print('Trying again.')
				print()
				return False

#################################################################################
#################################################################################
# the following uses an alternative to hdparm for listing specs of devices

	# print("If the device you want to erase is not listed, a deeper search can done.")
	# more = raw_input("Do you want to do this now? (y/n) ")
	# if(more == "y"):
	# 	logicalNameslshw = []
	# 	modelslshw = []
	# 	serialslshw = []
	# 	sizes1024lshw = []
	# 	sizes1000lshw = []

	# 	print
	# 	print "Gathering additional information..."
	# 	# i = -1
	# 	ps = subprocess.Popen(['lshw', '-class', 'disk'], stdout=subprocess.PIPE)
	# 	print
	# 	for line in ps.stdout:
	# 		if '*-disk' in line:
	# 			# initialize array entry
	# 			logicalNameslshw.append("")
	# 			modelslshw.append("")
	# 			serialslshw.append("")
	# 			sizes1024lshw.append("")
	# 			sizes1000lshw.append("")
	# 			print line,
	# 			continue

	# 		if 'description: ' in line:
	# 			print line,

	# 		elif 'logical name: /dev/' in line:
	# 			logicalNameslshw[len(logicalNameslshw) - 1] = line[26:-1]
	# 			print line[:20],
	# 			print('\033[1m\033[37m' + line[21:-1] + '\033[0m')

	# 		elif 'product: ' in line:
	# 			modelslshw[len(modelslshw) - 1] = line[16:-1]
	# 			print line,

	# 		elif 'serial: ' in line:
	# 			serialslshw[len(serialslshw) -1] = line[15:-1]
	# 			print line,

	# 		elif 'size: ' in line:
	# 			sizes1024lshw[len(sizes1024lshw) -1] = line[13:-1]
	# 			print line,

	# attributes2 = []
	# attributes2.append(logicalNameslshw)
	# attributes2.append(modelslshw)
	# attributes2.append(serialslshw)
	# attributes2.append(sizes1024lshw)

#################################################################################
#################################################################################

	return attributes

###########################################################################################################################################################
# confirmation

def confirm(attributes, index, checkNow):
	print('\033[0mPlease confirm the following operations: ')
	print()
	print('The following device will be irreversibly erased:')
	print()
	print("     \033[37m\033[1m/dev/" + attributes[0][index] + ", " + attributes[1][index] + ", " + attributes[2][index] + ", " + attributes[4][index].strip() + '\033[0m')
	print()
	if checkNow == 0:
		print("Afterwards, a Full Check will be done.")
	elif checkNow == 1:
		print("Afterwards, a Quick Check will be done.")
	elif checkNow == 2:
		print("Afterwards, no Check will be done.")
	else:
		print("Afterwards, you can choose what kind of check to do.")
	print()
	confirm = input('To confirm, type \033[37m\033[1m' + attributes[0][index] + '\033[0m. Invalid input will terminate the program due to safety\nreasons.\n' + \
						'Input: \033[1m\033[37m')
	if confirm != attributes[0][index]:
		print()
		print('Operation not confirmed by the user.')
		print('Program will terminate now.\033[0m')
		sys.exit()


###########################################################################################################################################################
# this function povides the nulling routine
# for this, the unix command 'dd' is being leveraged

def nulling(device, attributes, index, blocks):
	# confirm = raw_input('\033[0mDo you really want to irreversibly erase /dev/' + attributes[0][index] + '?\n' + \
	# 					'To confirm, type \033[37m\033[1m' + attributes[0][index] + '\033[0m. Invalid input will terminate the program.\n' + \
	# 					'Input: \033[1m\033[37m')
	# confirm(attributes, index, chec)
	# print
	# if confirm != attributes[0][index]:
	# 	print('\033[91mProgram terminated.\033[0m')
	# 	sys.exit()
	# elif confirm == attributes[0][index]:
	print()
	print('\033[1m\033[37m###############################################################################')
	print()

	beginDay = time.strftime("%d.%m.%Y")
	beginTime = time.strftime("%H:%M:%S %Z", time.localtime())
	print('\033[1m\033[37mBegin: ' + beginDay + ', ' + str(beginTime))
	print('\033[1m\033[37mnulling...')
	print()

	# deviceSize = modules[1].getDeviceSize('/dev/' + attributes[0][index])
	# dd = Popen(['dd', 'if=/dev/zero', 'of=/dev/' + attributes[0][index], 'bs=1M'], stderr=PIPE)
	# while dd.poll() is None: # check if child process has terminated
	# 	time.sleep(5)
	# 	dd.send_signal(signal.SIGUSR1)
	# 	while 1:
	# 		output = dd.stderr.readline()
	# 		output = output.decode('ascii')
	# 		if 'bytes' in output:
	# 			bytesWritten = output.split()[0]
	# 			try:
	# 				progress = output.strip() + ' ===> ' + str(math.floor((float(bytesWritten) / int(deviceSize)) * 100)) + '%'
	# 				stdout.write('\r%s' %progress)
	# 				# print(output.strip() + ' ===> ' + str(math.floor((float(bytesWritten) / int(deviceSize)) * 100)) + '%', end='\r'),
	# 			except ValueError as ex:
	# 				stdout.write('\r%s' %ex)
	# 				# print(ex, '\r'),
	# 			break
	# stdout.write('\n')
	# print(dd.stderr.read()),

	endDay = time.strftime("%d.%m.%Y")
	endTime = time.strftime("%H:%M:%S %Z", time.localtime())
	print('\033[1m\033[37mEnd: ' + endDay + ', ' + endTime)
	print('\033[0;32m\033[1mNulling ended successfully!')
	print()
	print('\033[1m\033[37m###############################################################################')
	print()

	duration = []
	duration.append(beginDay)
	duration.append(beginTime)
	duration.append(endDay)
	duration.append(endTime)

	return duration

###########################################################################################################################################################
# this function checks whether necessary dependencies are available
# if not, the program will terminate

def dependency_check():
	print('Checking dependencies...')

	moduleNames = ['__report', '__checking', 'pdfkit']
	tools = ['lsblk', 'dd', 'hdparm', 'lp', 'cupsd', 'wkhtmltopdf']

	# check for tools that are used for this tool
	for tool in tools:
		installed = distutils.spawn.find_executable(tool)
		if installed == None:
			print()
			print('\033[91m' + tool + ' is not installed, but required for this program to fully do its work.\nAfter installing, restart the program.\033[0m')
			print()
			print('Program will terminate now.')
			sys.exit()

	# check for python libraries that are used for this tool
	for module in moduleNames:
		try:
			modules.append(__import__(module, globals={"__name__": __name__}))
		except ImportError as ex:
			print(ex)
			print('\033[91m' + module + ' is not installed, but required for this program to fully do its work.\nAfter installing, restart the program.\033[0m')
			print()
			print('Program will terminate now.')
			sys.exit()
	print('Dependency check was succesfull.')
	print()

###########################################################################################################################################################

def precourse():
	print("""\033[0;32m\033[1m
###############################################################################
###############################################################################
####                                                                       ####
####     ###   ##  ##    ##  ##       ##       ##  ###   ##     ####       ####
####     ####  ##  ##    ##  ##       ##       ##  ####  ##   ##           ####
####     ## ## ##  ##    ##  ##       ##       ##  ## ## ##  ##   ####     ####
####     ##  ####  ##    ##  ##       ##       ##  ##  ####   ##    ##     ####
####     ##   ###    ####    #######  #######  ##  ##   ###     ####       ####
####                                                                       ####
####                                                                       ####
####                ########    ####        ####     ##                    ####
####                   ##     ##    ##    ##    ##   ##                    ####
####                   ##    ##      ##  ##      ##  ##                    ####
####                   ##     ##    ##    ##    ##   ##                    ####
####                   ##       ####        ####     #######               ####
####                                                                       ####
####                            \033[22mNulling Tool v1.0\033[1m                          ####
####                                                                       ####
###############################################################################
###############################################################################
\033[37m
###############################################################################

This Python script offers the ability to erase hard drives forensically sound.
After the nulling process, the hard drive will be checked to ensure that the
process ended successfully. Finally, a report (HTML as well as PDF) will be
created, which optionally can then be printed.

###############################################################################
  \033[m""")

###########################################################################################################################################################

if __name__ == '__main__':
    main()