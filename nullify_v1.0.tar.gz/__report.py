#!/usr/bin/env python3
# -*- coding: utf-8 -*-

############################################################################################################
############################################################################################################
# this file is part of the nulling tool (see nullify.py)
############################################################################################################
############################################################################################################

# import webbrowser
import time
import pdfkit
import os
import subprocess

############################################################################################################
# this function creates a html as well as pdf report of the nulling and checking process
# a report basically consists of two parts:
# at the top center, a full report is shown, which contains all necessary info for determining the device
# that was nulled as well as the case it belongs to
# furthermore, the user invoking the erasing process will be mentioned
# at the right bottom corner, a short report will be shown, containing only necessary info for determining 
# the case the device belongs to
# the short report is supposed to be attached to the device

def createReport(name, digiTraceID, duration, attributes, index, checked):
	# image that will be shown on the report
	# change path to custom image if necessary
	image = '../__DigiTrace_Logo_claim.png'

	print('\033[1m\033[37mCreating report...\033[0m')
	print

	# check if directory for reports already exists
	# create otherwise
	if not os.path.isdir("reports"):
		os.system("mkdir reports")

	# open html report file for writing
	f = open('reports/nulling_report_' + str(digiTraceID)+ '.html', 'w')


	# headline of full report
	top = \
	'<h1>' \
	+ '<b>L&ouml;schbest&auml;tigung</b>'

	# body of short report
	# depending on whether a check has been done, mention this on the report
	if checked == None:
		confirmation = '<p>' \
		+ '<i>Hiermit best&auml;tigt DigiTrace, dass nachfol-<br>gender Datentr&auml;ger vollst&auml;ndig IT-foren-<br>sisch gel&ouml;scht und gepr&uuml;ft wurde:</i>' \
		+ '</p>'
		shortReport = '<p style="margin:0">' \
			+ '<i>Vollst&auml;ndig genullt + unformatiert + gepr&uuml;ft</i><br><br>' \
			+ 'Fall: ' + str(digiTraceID) + '<br>' \
			+ 'Beginn: ' + duration[1] + ', ' + duration[0] + '<br>' \
			+ 'Ende: ' + duration[3] + ', ' + duration[2] + '<br>' \
			+ 'DigiTrace Mitarbeiter: ' + name + '<br>' \
			+ '<br><br>'\
			+ 'Unterschrift' \
		+ '</p>'
	else:
		confirmation = '<p>' \
		+ '<i>Hiermit best&auml;tigt DigiTrace, dass nachfol-<br>gender Datentr&auml;ger vollst&auml;ndig IT-foren-<br>sisch gel&ouml;scht, aber nicht gepr&uuml;ft wurde:</i>' \
		+ '</p>'
		shortReport = '<p style="margin:0">' \
			+ '<i>Vollst&auml;ndig genullt + unformatiert + ungepr&uuml;ft</i><br><br>' \
			+ 'Fall: ' + str(digiTraceID) + '<br>' \
			+ 'Beginn: ' + duration[1] + ', ' + duration[0] + '<br>' \
			+ 'Ende: ' + duration[3] + ', ' + duration[2] + '<br>' \
			+ 'DigiTrace Mitarbeiter: ' + name + '<br>' \
			+ '<br><br>'\
			+ 'Unterschrift' \
		+ '</p>'

	# full report
	fullReport = '<p>' \
			+ 'Fall: ' + str(digiTraceID) + '<br>' \
			+ 'Modell: ' + attributes[1][index] + '<br>' \
			+ 'S/N: ' + attributes[2][index] + '<br>' \
			+ 'Gr&ouml;&szlig;e: ' + attributes[4][index] + '<br>' \
			+ 'Beginn: ' + duration[1] + ', ' + duration[0] + '<br>' \
			+ 'Ende: ' + duration[3] + ', ' + duration[2] + '<br>' \
			+ 'DigiTrace Mitarbeiter: ' + name + '<br>' \
			+ '<br><br>'\
			+ 'Unterschrift' \
		+ '</p>'

	# beginning of html DOM tree
	# adjust size of image if necessary
	tree = \
	"""<!DOCTYPE html>
		<html>
			<head></head>
			<body style="background-color:#ffffff">
				<div>
					<div>
						<img src=""" + image + """ alt="DigiTrace_Logo" style="max-width:300px">
					</div>
					<div id="top">
						""" + top + """
					</div>
					<div id="confirmation">
						""" + confirmation + """
					</div>
					<div id="main">
						""" + fullReport + """
					</div>
				</div>
				<div style="position:relative;height:805px;">
					<div style="position:absolute;bottom:0;right:-5px;border-left:1px solid #000;border-top:1px solid #000;padding:5px">
						<div style="float:right;">
							<img src=""" + image + """ alt="DigiTrace_Logo" style="max-width:145px">
						</div>
						<div style="float:right;">
							""" + shortReport + """
						</div>
					</div>
				</div>
			</body>
		<html>
	"""

	# write html file
	f.write(tree)
	f.close()

	# options for converting html to pdf
	options = {
    'page-size': 'A4',
    'margin-top': '0in',
    'margin-right': '0in',
    'margin-bottom': '0in',
    'margin-left': '2.5in',
    'encoding': "UTF-8",
	}
	
	# convert html to pdf
	pdfkit.from_url('reports/nulling_report_' + str(digiTraceID)+ '.html', 'reports/nulling_report_' + str(digiTraceID) + '.pdf', options=options)

	return 'reports/nulling_report_' + str(digiTraceID) + '.pdf'
	############################################################################################################